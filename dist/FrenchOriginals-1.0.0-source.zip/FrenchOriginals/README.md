# French Originals for Jellyfin 12

Native Jellyfin plugin, version **1.0.0.0**. Runs from Scheduled Tasks or the plugin's **Run with saved settings** button. No API key, Python runtime, Docker sidecar, or external scheduler is needed on your server.

## Install on Unraid / Docker

1. Disable the old `run_jf_fr_metadata.sh` schedule so both tools do not work on the same items.
2. Stop the Jellyfin container and back up its persistent appdata/config directory. If you use NFO saving, include the affected NFO files in your backup: Jellyfin's normal metadata savers can update them.
3. Extract the release ZIP. Copy the **entire `FrenchOriginals_1.0.0.0` folder** into Jellyfin's existing **plugins** directory. Do not copy the source ZIP, build dependencies, or the test provider there.
4. Start Jellyfin. Open **Dashboard → Plugins → My Plugins → French Originals**.
5. Select your Movies and TV libraries. Leave **Preview only** enabled, set **Items per run** to `5` for the first check, and save. Click **Run with saved settings**, then **Refresh report**.
6. Review the proposed titles. Disable **Preview only**, save, and run again. After that, use an item limit such as `25` or `80`. The default safety guard is `80` selected items.
7. For automation, add a daily trigger under **Dashboard → Scheduled Tasks → French Originals — update metadata**. Choose a time after your library scan normally finishes. No automatic trigger is installed by default.

Use the actual persistent plugins directory for your image. In the official Jellyfin container it is normally `/config/plugins`; LinuxServer images commonly use `/config/data/plugins`. On Unraid these paths map to the host appdata directory shown in the container's volume mappings. The correct directory is the one containing your other plugin folders and `configurations`.

Example resulting layout:

```text
plugins/
  FrenchOriginals_1.0.0.0/
    Jellyfin.Plugin.FrenchOriginals.dll
    meta.json
```

This is a manual-install package, not a hosted plugin catalog. Updates are installed by stopping Jellyfin, replacing the old plugin folder, and restarting. Keep only one installed version of this plugin. No custom .NET installation is required inside the Jellyfin container.

## What changes

- Films and series must have a French `OriginalLanguage` recorded in Jellyfin (`fr`, `fra`, `fre`, including regional forms). French dubbing or subtitles alone do not qualify an item. Missing or ambiguous original languages are skipped.
- The plugin sets `PreferredMetadataLanguage` to `fr`, retaining an already-French regional preference such as `fr-CA`.
- With text updates enabled, it requests French metadata from your library's enabled remote providers, in their configured order. It accepts responses only when an existing provider ID matches and no shared provider ID conflicts. Name-only matches are not accepted.
- Only the preference, unlocked title, and unlocked overview are assigned. Empty provider text never erases existing text. Country, ratings, tags, provider IDs, metadata locks, images, audio/subtitles, and watched status are not intentionally changed. It does not queue a library scan, image refresh, media probe, or full metadata replacement.
- Globally locked items are skipped. Individual title/overview locks remain in force.
- Optional season and episode processing uses a French-original parent series. A locked parent, a known non-French child original language, or an explicit non-French child metadata preference causes that child to be skipped. Children without a verifiable existing provider ID may be skipped even if the series can be updated.
- Unchecking **Update titles and summaries** changes only movie/series language preferences and makes no provider requests. It does not translate existing text; re-enable text updates when needed.

This deliberately makes a narrower update than a normal Jellyfin metadata refresh. Your Python script used `FullRefresh` with `ReplaceAllMetadata=false`; that can preserve already-populated English text. This plugin copies the requested French title and summary explicitly while preserving unrelated fields.

## Safety, retries, and performance

Preview mode may read provider metadata and populate provider caches, but never saves library metadata or completion markers. Its report shows exact proposed titles for the selected batch. Both preview and apply keep diagnostic reports and journals.

Every run inventories the selected libraries before writes. **Items per run** limits the selected batch; `0` selects all pending candidates. Apply refuses the entire batch if its selected count exceeds **Maximum selected items allowed in apply mode**. Each season and episode counts as one item. A preview is not an immutable transaction: apply rechecks the current library and provider results.

Completed items are fingerprinted. Subsequent runs skip them unless their relevant metadata changes, you change between language-only and text mode, or you enable **Recheck completed items**. A title already set to French by your script still receives one text check the first time this plugin sees it. Failed or partial lookups remain retryable and move behind unattempted items, so one problematic title does not block a batch indefinitely. Disable **Recheck completed items** for normal daily operation.

Only one plugin run is allowed at a time. Processing is sequential, with a default 200 ms delay between items and a 30-second timeout per provider. The task refuses to run while a library scan or metadata refresh queue is active and stops if one starts. Run again later; completed work is recorded. Cancelling through Scheduled Tasks finishes/verifies an already-started item save, then stops before the next item.

Before each write, the plugin flushes an audit record to disk, checks for concurrent edits, saves through Jellyfin's library API, and reads the stored item back. Verification failure stops subsequent writes. It never directly opens or edits the Jellyfin database. Third-party plugins can still react to Jellyfin's normal item-update events; concurrent changes cannot be made globally atomic across unrelated plugins.

## Reports and recovery

The configuration page displays the last run and up to 200 result rows. Its report endpoint requires administrator privileges. The full journals are JSON Lines files in **`<Jellyfin data directory>/FrenchOriginals/journals`**; this is the data directory containing `jellyfin.db`, which may be one level below the container's `/config`. `last-run.json` and `completed.json` are in the same `FrenchOriginals` data folder. The exact location follows the server's configured paths.

Journals are retained for 30 days by default. `prepared` records contain the old language/title/overview and the intended values; `verified` records contain the verified result. For a small manual correction, disable this task and restore those values in Jellyfin's metadata editor. There is no automatic rollback that might overwrite subsequent manual edits. Restoring a full backup is the recovery path for broader changes.

If a completion file becomes unreadable, the task stops rather than silently losing its history. With Jellyfin stopped, preserve that file for diagnosis and restore it from backup, or rename only `completed.json` to force a fresh pass. Removing or disabling the plugin does **not** undo changes already applied.

## Limits

French translations must exist in the enabled metadata provider. The plugin does not machine-translate text. Some providers silently return fallback text despite a French request; the plugin cannot reliably detect the language of arbitrary prose. Missing fields are preserved and retried, and explicitly non-French response languages are rejected.

It does not infer a missing original language from filenames, audio tracks, or country. Fix incorrect or absent original-language metadata through Jellyfin or the upstream provider first. It does not change the library's global language, the UI language, preferred audio language, or episode/season numbering.

Compatibility target: **Jellyfin 12.x / .NET 10**. Runtime refuses other major versions. See `VALIDATION.md` for the exact builds tested and remaining limits. Preview a small batch on your own server before enabling scheduled apply.

## Build and tests

Install the .NET 10 SDK on a development machine, then run:

```sh
dotnet restore src/Jellyfin.Plugin.FrenchOriginals --locked-mode
dotnet build src/Jellyfin.Plugin.FrenchOriginals -c Release --no-restore
dotnet run --project tests/FrenchOriginals.Tests -c Release
python3 package.py
```

The plugin references Jellyfin's official 12.0.0 NuGet packages. Its ZIP contains only its own DLL and plugin metadata; Jellyfin supplies the framework and host assemblies. Keep the source and license alongside any redistribution. The code is licensed GPL-3.0-only.

The integration fixture under `tests/SmokeProvider` is for disposable test servers only. It returns synthetic French text and must **never** be installed on a real media server. `tests/run-smoke.py` requires a fresh empty work directory and starts/stops its own server process. See the validation notes for invocation.

## References

- [Jellyfin manual plugin installation](https://jellyfin.org/docs/general/server/plugins/#manual)
- [Jellyfin 12 release and plugin compatibility](https://jellyfin.org/posts/jellyfin-release-12.0/)
- [Jellyfin 12.0 provider API](https://github.com/jellyfin/jellyfin/blob/v12.0/MediaBrowser.Controller/Providers/IProviderManager.cs)
- [Jellyfin 12.0 metadata merge behavior](https://github.com/jellyfin/jellyfin/blob/v12.0/MediaBrowser.Providers/Manager/MetadataService.cs)
