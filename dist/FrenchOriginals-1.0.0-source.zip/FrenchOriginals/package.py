#!/usr/bin/env python3
"""Package already-built release bytes; no network access or credentials."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parent
out=root/'artifacts';out.mkdir(exist_ok=True)
dll=root/'src/Jellyfin.Plugin.FrenchOriginals/bin/Release/net10.0/Jellyfin.Plugin.FrenchOriginals.dll'
if not dll.is_file():raise SystemExit('Build the Release configuration first.')
manifest={
 'category':'Metadata','guid':'8a18225a-22b8-4e18-9921-b8f1b5900bbc',
 'name':'French Originals','description':'French titles and summaries for French-original films and television.',
 'owner':'French Originals','overview':'Scheduled French metadata updates with preview, scope controls, and audit logging.',
 'targetAbi':'12.0.0.0','version':'1.0.0.0','status':'Active','autoUpdate':False,
 'assemblies':['Jellyfin.Plugin.FrenchOriginals.dll']}
release=out/'FrenchOriginals-1.0.0-jellyfin12.zip'
def add(z,name,data):
 info=zipfile.ZipInfo(name,(2026,9,22,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
with zipfile.ZipFile(release,'w') as z:
 add(z,'FrenchOriginals_1.0.0.0/'+dll.name,dll.read_bytes())
 add(z,'FrenchOriginals_1.0.0.0/meta.json',json.dumps(manifest,indent=2).encode())
 for name in ['README.md','VALIDATION.md','LICENSE']:
  add(z,name,(root/name).read_bytes())
source=out/'FrenchOriginals-1.0.0-source.zip'
with zipfile.ZipFile(source,'w') as z:
 for p in sorted(root.rglob('*')):
  relative=p.relative_to(root)
  if p.is_file() and not any(s in ['bin','obj','artifacts','.git','__pycache__','node_modules'] for s in relative.parts):
   add(z,'FrenchOriginals/'+relative.as_posix(),p.read_bytes())
sha=out/'SHA256SUMS.txt'
sha.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in [release,source]))
print('\n'.join(str(p) for p in [release,source,sha]))
